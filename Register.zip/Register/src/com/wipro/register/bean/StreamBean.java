package com.wipro.register.bean;

public class StreamBean 
{
	private String streamname;
	private String streamid;
	private String streamdetails;
	private String comments;
	public String getStreamname() {
		return streamname;
	}
	public void setStreamname(String streamname) {
		this.streamname = streamname;
	}
	public String getStreamid() {
		return streamid;
	}
	public void setStreamid(String streamid) {
		this.streamid = streamid;
	}
	public String getStreamdetails() {
		return streamdetails;
	}
	public void setStreamdetails(String streamdetails) {
		this.streamdetails = streamdetails;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
}